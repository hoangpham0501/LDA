library( lattice )
savedModel <- read.ml("/home/hduser/Python/lda")
topic_model <- summary(savedModel)
cold_and_hot_ts <- cbind( theta_mean_by_year_ts[, topics_cold [1:2]] ,
                           theta_mean_by_year_ts[, topics_hot [1:2]] , deparse.level =0)
colnames( cold_and_hot_ts) <- as.character(c( topics_cold[1:2] , topics_hot[1:2]) )

topics_word_hot <- topics_hot[1:2]
topics_word_cold <- topics_cold[1:2]

# 10 words of term of hot and cold topics
terms_word <- topic_model$topics
terms_list <- collect(select(terms_word, terms_word$term))

terms_word_hot <- terms_list$term[topics_word_hot]
terms_word_cold <- terms_list$term[topics_word_cold]



print( xyplot( cold_and_hot_ts ,layout = c(2, 1) ,
               screens = c(rep("Cold topics", 2) , rep("Hot topics", 2)),
               superpose = TRUE ,
               ylim = c(0, 0.01) ,
               ylab = expression( paste("Mean",theta )),
               xlab = "Year",
               type = c("l", "g"),
               auto.key = list( space = "right"),
               scales = list(x = list(alternating = FALSE))))