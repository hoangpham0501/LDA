# Reading abtracts corpus
for (year in 2014:2016){
  path = paste("/home/hduser/Python/abstract source/", toString(year), "/*.txt", sep = "")
  abstract <- read.text(path)
  abstract_df <- withColumn(abstract, "year", lit(year))
  write.df(abstract_df, "/home/hduser/RSpark/abstract/", mode = "append", source="csv")
}
