Sys.setenv(SPARK_HOME = "/usr/local/spark-2.1.0-bin-hadoop2.6")
library(SparkR, lib.loc = c(file.path(Sys.getenv("SPARK_HOME"), "R", "lib")))

sparkR.session(master = "local[3]", sparkEnvir = list(spark.driver.memory="4g", spark.executor.memory="4g"))

meta_data <- read.df("/home/hduser/RSpark/meta.csv", "csv", header = "true", 
                     inferSchema = "true", na.strings = "NA")

# terminate Spark session
#sparkR.stop()