data_year <- filter(meta_data, meta_data$year == "2016")

categories_2016_major <- collect(select(data_year, data_year$category))
categories_2016_minor <- collect(select(data_year, data_year$category_merged))

# Create data frame
categories_2016 <- data.frame(major = categories_2016_major, minor = categories_2016_minor, stringsAsFactors =  FALSE)
categories_2016$major_abbr <- factor(unlist(categories_2016_major))

# Match categories with their short names
levels(categories_2016$major_abbr) <- c("(BS)", "(HOSF)", "(KS)", "(MEF)", "(NMSF)", "(Per)", 
                                        "(PS)", "(SCCH)", "(SCDC)", "(SCIF)", "(SCLE)", "(SS)")

categories_2016$pretty <- paste(categories_2016$category_merged, categories_2016$major_abbr)

# differentiate major categories by color
category_levels <- unique(categories_2016)

category_levels <- category_levels[order(category_levels$category,
                                         category_levels$category_merged),]

rownames(category_levels) <- make.names(category_levels$pretty, unique = TRUE)
category_levels$color <- factor(unlist(category_levels$major_abbr))
#Match color with the category_level
levels(category_levels$color) <- c("#00CC33", "#0033CC", "#CC0099", "#00EEFF", "#00EE00", "#0000FF",
                                   "#EE00FF", "#FFEE00", "#EE3300", "#9900CC", "#CC00CC", "#FF00FF")
category_levels$color <- paste(category_levels$color)