# Add stop word list
my_stopwords <- read.table("/home/hduser/Test/stopwords-en.txt", sep=",",quote ="\"", 
                           comment.char = "", encoding = "UTF-8", stringsAsFactors = F)
adverbs <- read.table("/home/hduser/Test/adverbs.txt", sep=",",quote ="\"", 
                      comment.char = "", encoding = "UTF-8", stringsAsFactors = F)

my_stopwords <- as.character(my_stopwords$V1)
adverbs <- as.character(adverbs$V1)
my_stopwords <- c(my_stopwords, adverbs)

year_list <- collect(select(meta_data, meta_data$year))
year_list <- as.vector(year_list$year)

abstract <- read.df("/home/hduser/RSpark/abstract", source = "csv")

# Create model_lda 
system.time(model_lda <- spark.lda(abstract, features = "_c0", k = 20, maxIter = 40, optimizer = c("online", "em"), 
                                   subsamplingRate = 0.05,
                                   topicConcentration = -1, docConcentration = -1,
                                   customizedStopWords = my_stopwords, maxVocabSize = bitwShiftL(1, 18)))

write.ml(model_lda, "/home/hduser/Python/lda", overwrite = TRUE)