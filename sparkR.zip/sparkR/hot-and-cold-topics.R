
years <- levels(factor(year_list))
topics_n <- 20
theta <- spark.posterior(model_lda, select(abstract, abstract$`_c0`))
theta <- collect(select(theta, theta$topicDistribution))
theta_matrix <-matrix(unlist(theta$topicDistribution),  ncol = 20, byrow = TRUE)

theta_mean_by_year_by <- by(theta_matrix, year_list, colMeans)
theta_mean_by_year <- do.call("rbind",theta_mean_by_year_by)
colnames(theta_mean_by_year) = paste(1:topics_n)
theta_mean_by_year_ts <- ts(theta_mean_by_year, start = as.integer(years[1]))
theta_mean_by_year_time <- time(theta_mean_by_year)


theta_mean_lm <- apply(theta_mean_by_year, 2, function(x) lm(x ~ theta_mean_by_year_time))
theta_mean_lm_coef <- lapply(theta_mean_lm, function(x) coef(summary(x)))

theta_mean_lm_coef_sign <- sapply(theta_mean_lm_coef, '[',"theta_mean_by_year_time", "Pr(>|t|)")
theta_mean_lm_coef_slope <- sapply(theta_mean_lm_coef,'[',"theta_mean_by_year_time", "Estimate")


# Divide the trend slopes into positive and negative slopes
theta_mean_lm_coef_slope_pos <- theta_mean_lm_coef_slope[theta_mean_lm_coef_slope >= 0]

theta_mean_lm_coef_slope_neg <- theta_mean_lm_coef_slope[theta_mean_lm_coef_slope < 0]

p_level <- c(0.2, 0.1, 0.01, 0.001)
significance_total <- sapply(p_level,
                             function(x) (theta_mean_lm_coef_sign[theta_mean_lm_coef_sign < x]))
#print(significance_total)
significance_neg <- sapply(1:length(p_level),
                           function(x) intersect(names(theta_mean_lm_coef_slope_neg),
                                                 names(significance_total[[x]])))
significance_pos <- sapply(1:length(p_level),
                           function(x) intersect(names(theta_mean_lm_coef_slope_pos),
                                                 names(significance_total[[x]])))

topics_hot <- as.numeric(names(sort(theta_mean_lm_coef_slope[significance_pos[[1]]], decreasing = TRUE)))
topics_cold <- as.numeric(names(sort(theta_mean_lm_coef_slope[significance_neg[[1]]], decreasing = FALSE)))